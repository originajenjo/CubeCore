package carlos2025.MystiCubPvP.Eventos;

public class Explociones {

}

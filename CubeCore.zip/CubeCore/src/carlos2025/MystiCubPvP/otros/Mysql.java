package carlos2025.MystiCubPvP.otros;

public class Mysql {

}
